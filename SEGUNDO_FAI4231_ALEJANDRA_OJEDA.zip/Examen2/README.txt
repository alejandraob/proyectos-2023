
*------------------------*     EXAMEN PARCIAL NRO 1    *------------------------*
Fecha:21/04/2023
Sala: Maria Laura
Nombre y Apellido: Alejandra Ojeda
Tecnico Univ. Desarrollo Web
Legajo 4231
*------------------------* *------------------------* *------------------------* 